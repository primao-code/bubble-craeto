"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Monitor, Smartphone, Tablet, Eye, RotateCcw, MousePointer, Zap, Database, ImageIcon } from "lucide-react"
import type { JSX } from "react/jsx-runtime"

interface BubbleVisualizationProps {
  json: string
}

export function BubbleVisualization({ json }: BubbleVisualizationProps) {
  const [parsedJson, setParsedJson] = useState<any>(null)
  const [viewMode, setViewMode] = useState<"desktop" | "tablet" | "mobile">("desktop")
  const [showGrid, setShowGrid] = useState(false)
  const [showIds, setShowIds] = useState(false)
  const [interactiveMode, setInteractiveMode] = useState(false)
  const [selectedElement, setSelectedElement] = useState<string | null>(null)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!json.trim()) {
      setParsedJson(null)
      setError("")
      return
    }

    try {
      const parsed = JSON.parse(json)
      setParsedJson(parsed)
      setError("")
    } catch (err) {
      setError("JSON inválido para visualização")
      setParsedJson(null)
    }
  }, [json])

  const getViewportStyles = () => {
    switch (viewMode) {
      case "mobile":
        return {
          width: "375px",
          height: "667px",
          maxHeight: "600px",
        }
      case "tablet":
        return {
          width: "768px",
          height: "1024px",
          maxHeight: "600px",
        }
      default:
        return {
          width: "100%",
          height: "auto",
          minHeight: "500px",
        }
    }
  }

  const renderBubbleElement = (element: any, depth = 0): JSX.Element => {
    const { type, uid, text, placeholder, elements, styles = {} } = element
    const isSelected = selectedElement === uid
    const elementId = uid || `element_${Math.random().toString(36).substr(2, 9)}`

    const baseClasses = `
    transition-all duration-200 
    ${isSelected ? "ring-2 ring-blue-500 ring-offset-2" : ""}
    ${interactiveMode ? "cursor-pointer hover:shadow-md" : ""}
  `

    const handleElementClick = (e: React.MouseEvent) => {
      if (interactiveMode) {
        e.stopPropagation()
        setSelectedElement(isSelected ? null : elementId)
      }
    }

    switch (type) {
      case "Group":
        const isRow = element.container_layout_type === "row"
        return (
          <div
            key={elementId}
            className={`
            ${baseClasses}
            border border-gray-200 rounded-lg p-4 mb-3
            ${isRow ? "flex flex-row gap-4 items-start" : "flex flex-col gap-3"}
            bg-white shadow-sm
          `}
            onClick={handleElementClick}
            style={{
              gap: `${element.gap || 10}px`,
              backgroundColor: styles["background-color"] || "#ffffff",
              borderRadius: styles["border-radius"] || "8px",
            }}
          >
            {showIds && (
              <div className="absolute -top-2 -left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                Group #{elementId.slice(-6)}
              </div>
            )}
            {elements && elements.length > 0 ? (
              elements.map((child: any) => renderBubbleElement(child, depth + 1))
            ) : (
              <div className="text-gray-400 text-sm italic p-4 border-2 border-dashed border-gray-200 rounded">
                Grupo vazio - Adicione elementos aqui
              </div>
            )}
          </div>
        )

      case "Text":
        return (
          <div key={elementId} className={`${baseClasses} relative inline-block`} onClick={handleElementClick}>
            {showIds && (
              <div className="absolute -top-6 left-0 bg-green-500 text-white text-xs px-2 py-1 rounded">
                Text #{elementId.slice(-6)}
              </div>
            )}
            <p
              className="m-0"
              style={{
                fontSize: styles["font-size"] || "14px",
                fontWeight: styles["font-weight"] || "400",
                color: styles.color || "#000000",
                lineHeight: "1.4",
              }}
            >
              {text || "Texto de exemplo"}
            </p>
          </div>
        )

      case "Input":
        return (
          <div key={elementId} className={`${baseClasses} relative`} onClick={handleElementClick}>
            {showIds && (
              <div className="absolute -top-6 left-0 bg-purple-500 text-white text-xs px-2 py-1 rounded">
                Input #{elementId.slice(-6)}
              </div>
            )}
            <input
              type={element.input_type || "text"}
              placeholder={placeholder || "Digite aqui..."}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              style={{
                width: styles.width || "200px",
                height: styles.height || "40px",
                fontSize: "14px",
              }}
              disabled={!interactiveMode}
            />
          </div>
        )

      case "Button":
        return (
          <div key={elementId} className={`${baseClasses} relative inline-block`} onClick={handleElementClick}>
            {showIds && (
              <div className="absolute -top-6 left-0 bg-orange-500 text-white text-xs px-2 py-1 rounded">
                Button #{elementId.slice(-6)}
              </div>
            )}
            <button
              className="px-4 py-2 rounded-md font-medium transition-colors hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2"
              style={{
                backgroundColor: styles["background-color"] || "#1976d2",
                color: styles.color || "#ffffff",
                borderRadius: styles["border-radius"] || "4px",
                width: styles.width || "auto",
                height: styles.height || "40px",
                fontSize: "14px",
              }}
              disabled={!interactiveMode}
            >
              {text || "Clique aqui"}
            </button>
          </div>
        )

      case "Image":
        return (
          <div key={elementId} className={`${baseClasses} relative`} onClick={handleElementClick}>
            {showIds && (
              <div className="absolute -top-6 left-0 bg-pink-500 text-white text-xs px-2 py-1 rounded">
                Image #{elementId.slice(-6)}
              </div>
            )}
            <div
              className="bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-500"
              style={{
                width: styles.width || "100px",
                height: styles.height || "100px",
                borderRadius: styles["border-radius"] || "0px",
              }}
            >
              <div className="text-center">
                <ImageIcon className="h-6 w-6 mx-auto mb-1" />
                <span className="text-xs">Imagem</span>
              </div>
            </div>
          </div>
        )

      case "RepeatingGroup":
        return (
          <div
            key={elementId}
            className={`${baseClasses} border-2 border-purple-200 rounded-lg p-4 bg-purple-50`}
            onClick={handleElementClick}
          >
            {showIds && (
              <div className="absolute -top-6 left-0 bg-purple-600 text-white text-xs px-2 py-1 rounded">
                RG #{elementId.slice(-6)}
              </div>
            )}
            <div className="flex items-center gap-2 mb-3">
              <Database className="h-4 w-4 text-purple-600" />
              <span className="font-medium text-sm text-purple-800">Repeating Group</span>
              <Badge variant="outline" className="text-xs">
                {element.type_of_content || "Data"}
              </Badge>
            </div>
            <div className="text-xs text-purple-700 mb-3">
              Data Source: {element.data_source || "Search for Things"}
            </div>
            <div className="space-y-2">
              {/* Simular 3 células */}
              {[1, 2, 3].map((index) => (
                <div key={index} className="bg-white p-3 rounded border border-purple-200">
                  <div className="text-xs text-purple-600 mb-2">Cell {index}:</div>
                  {elements && elements.length > 0 ? (
                    <div className="space-y-2">
                      {elements.map((child: any) => renderBubbleElement(child, depth + 1))}
                    </div>
                  ) : (
                    <div className="text-gray-400 text-xs italic">Template da célula</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )

      default:
        return (
          <div
            key={elementId}
            className={`${baseClasses} p-3 bg-yellow-50 border border-yellow-200 rounded`}
            onClick={handleElementClick}
          >
            {showIds && (
              <div className="absolute -top-6 left-0 bg-yellow-500 text-white text-xs px-2 py-1 rounded">
                {type} #{elementId.slice(-6)}
              </div>
            )}
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-yellow-800">
                {type}: {text || placeholder || "Elemento customizado"}
              </span>
            </div>
          </div>
        )
    }
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!parsedJson || !parsedJson.elements || parsedJson.elements.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="h-5 w-5" />
            Visualização Interativa
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <div className="text-center">
              <Eye className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Gere um JSON primeiro para visualizar os elementos</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const renderElements = (elements: any[]): JSX.Element[] => {
    return elements.map((element: any) => renderBubbleElement(element))
  }

  const renderElementDefinitions = (elementDefinitions: any): JSX.Element[] => {
    return Object.values(elementDefinitions).map((element: any) => renderBubbleElement(element))
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Monitor className="h-5 w-5" />
            Visualização Interativa dos Elementos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4">
            {/* Viewport Controls */}
            <div className="flex items-center gap-2">
              <Label className="text-sm font-medium">Dispositivo:</Label>
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant={viewMode === "desktop" ? "default" : "outline"}
                  onClick={() => setViewMode("desktop")}
                >
                  <Monitor className="h-3 w-3 mr-1" />
                  Desktop
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === "tablet" ? "default" : "outline"}
                  onClick={() => setViewMode("tablet")}
                >
                  <Tablet className="h-3 w-3 mr-1" />
                  Tablet
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === "mobile" ? "default" : "outline"}
                  onClick={() => setViewMode("mobile")}
                >
                  <Smartphone className="h-3 w-3 mr-1" />
                  Mobile
                </Button>
              </div>
            </div>

            {/* View Options */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch id="grid" checked={showGrid} onCheckedChange={setShowGrid} />
                <Label htmlFor="grid" className="text-sm">
                  Grid
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="ids" checked={showIds} onCheckedChange={setShowIds} />
                <Label htmlFor="ids" className="text-sm">
                  IDs
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch id="interactive" checked={interactiveMode} onCheckedChange={setInteractiveMode} />
                <Label htmlFor="interactive" className="text-sm">
                  Interativo
                </Label>
              </div>
            </div>

            {/* Reset */}
            <Button size="sm" variant="outline" onClick={() => setSelectedElement(null)}>
              <RotateCcw className="h-3 w-3 mr-1" />
              Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Visualization Area */}
      <Card>
        <CardContent className="p-0">
          <div className="flex">
            {/* Main Viewport */}
            <div className="flex-1 p-6">
              <div
                className={`
                mx-auto border border-gray-300 rounded-lg overflow-auto
                ${showGrid ? "bg-grid-pattern" : "bg-gray-50"}
                ${viewMode !== "desktop" ? "shadow-lg" : ""}
              `}
                style={getViewportStyles()}
              >
                <div className="p-6 h-full">
                  {/* Device Header */}
                  {viewMode !== "desktop" && (
                    <div className="flex items-center justify-center mb-4 pb-2 border-b border-gray-200">
                      <Badge variant="outline" className="text-xs">
                        {viewMode === "mobile" ? "iPhone 12" : "iPad Pro"} - {viewMode}
                      </Badge>
                    </div>
                  )}

                  {/* Elements */}
                  <div className="space-y-4">
                    {parsedJson.element_definitions
                      ? renderElementDefinitions(parsedJson.element_definitions)
                      : parsedJson.elements
                        ? renderElements(parsedJson.elements)
                        : null}
                  </div>
                </div>
              </div>
            </div>

            {/* Element Inspector */}
            {selectedElement && (
              <div className="w-80 border-l border-gray-200 p-4 bg-gray-50">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <MousePointer className="h-4 w-4" />
                    <span className="font-medium text-sm">Elemento Selecionado</span>
                  </div>

                  <div className="bg-white p-3 rounded border">
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium">ID:</span> #{selectedElement.slice(-6)}
                      </div>
                      <div>
                        <span className="font-medium">Tipo:</span> {getElementType(selectedElement, parsedJson)}
                      </div>
                      <div>
                        <span className="font-medium">Propriedades:</span>
                        <pre className="text-xs bg-gray-100 p-2 rounded mt-1 overflow-auto max-h-32">
                          {JSON.stringify(getElementProperties(selectedElement, parsedJson), null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>

                  <Button size="sm" variant="outline" onClick={() => setSelectedElement(null)} className="w-full">
                    Fechar Inspetor
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Element Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{countElementsByType(parsedJson, "Group")}</div>
            <div className="text-sm text-gray-600">Groups</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{countElementsByType(parsedJson, "Text")}</div>
            <div className="text-sm text-gray-600">Textos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{countElementsByType(parsedJson, "Input")}</div>
            <div className="text-sm text-gray-600">Inputs</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{countElementsByType(parsedJson, "Button")}</div>
            <div className="text-sm text-gray-600">Botões</div>
          </CardContent>
        </Card>
      </div>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Como usar a Visualização</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">Controles:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>
                  • <strong>Dispositivo:</strong> Mude entre Desktop, Tablet e Mobile
                </li>
                <li>
                  • <strong>Grid:</strong> Mostra grade de alinhamento
                </li>
                <li>
                  • <strong>IDs:</strong> Exibe identificadores dos elementos
                </li>
                <li>
                  • <strong>Interativo:</strong> Permite clicar nos elementos
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Funcionalidades:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>
                  • <strong>Clique:</strong> Selecione elementos no modo interativo
                </li>
                <li>
                  • <strong>Inspetor:</strong> Veja propriedades do elemento selecionado
                </li>
                <li>
                  • <strong>Responsivo:</strong> Teste em diferentes tamanhos
                </li>
                <li>
                  • <strong>Preview Real:</strong> Veja exatamente como ficará no Bubble
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Helper functions
function getElementType(uid: string, json: any): string {
  const findElement = (elements: any[]): any => {
    for (const element of elements) {
      if (element.uid === uid) return element
      if (element.elements) {
        const found = findElement(element.elements)
        if (found) return found
      }
    }
    return null
  }

  const element = findElement(json.elements || [])
  return element?.type || "Unknown"
}

function getElementProperties(uid: string, json: any): any {
  const findElement = (elements: any[]): any => {
    for (const element of elements) {
      if (element.uid === uid) return element
      if (element.elements) {
        const found = findElement(element.elements)
        if (found) return found
      }
    }
    return null
  }

  const element = findElement(json.elements || [])
  if (!element) return {}

  const { elements, ...properties } = element
  return properties
}

function countElementsByType(json: any, type: string): number {
  let count = 0

  const countInElements = (elements: any[]) => {
    elements.forEach((element) => {
      if (element.type === type) count++
      if (element.elements) countInElements(element.elements)
    })
  }

  if (json.elements) countInElements(json.elements)
  return count
}
