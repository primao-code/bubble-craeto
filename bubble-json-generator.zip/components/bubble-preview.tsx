"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Monitor, Smartphone, Tablet, Eye, Code2, Layers, Zap, Database, FileText } from "lucide-react"
import type { JSX } from "react/jsx-runtime" // Import JSX to fix the undeclared variable error

interface BubblePreviewProps {
  json: string
}

export function BubblePreview({ json }: BubblePreviewProps) {
  const [parsedJson, setParsedJson] = useState<any>(null)
  const [previewMode, setPreviewMode] = useState<"desktop" | "tablet" | "mobile">("desktop")
  const [error, setError] = useState("")

  useEffect(() => {
    if (!json.trim()) {
      setParsedJson(null)
      setError("")
      return
    }

    try {
      const parsed = JSON.parse(json)
      setParsedJson(parsed)
      setError("")
    } catch (err) {
      setError("JSON inválido para preview")
      setParsedJson(null)
    }
  }, [json])

  const renderBubbleElement = (element: any, depth = 0): JSX.Element => {
    const { type, uid, text, placeholder, elements } = element
    const indent = depth * 16

    switch (type) {
      case "Group":
        return (
          <div
            key={uid}
            className="border border-blue-200 rounded-lg p-3 mb-2 bg-blue-50"
            style={{ marginLeft: indent }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Layers className="h-4 w-4 text-blue-600" />
              <span className="font-medium text-sm text-blue-800">Group</span>
              <Badge variant="outline" className="text-xs">
                {element.container_layout_type || "column"}
              </Badge>
              <span className="text-xs text-gray-500">#{uid?.slice(-6)}</span>
            </div>
            {elements && elements.length > 0 && (
              <div className="space-y-1">{elements.map((child: any) => renderBubbleElement(child, depth + 1))}</div>
            )}
          </div>
        )

      case "Text":
        return (
          <div
            key={uid}
            className="flex items-center gap-2 p-2 bg-white rounded border border-gray-200"
            style={{ marginLeft: indent }}
          >
            <FileText className="h-3 w-3 text-gray-600" />
            <span className="text-sm font-medium">Text:</span>
            <span className="text-sm text-gray-700">{text || "Texto"}</span>
            <span className="text-xs text-gray-400">#{uid?.slice(-6)}</span>
          </div>
        )

      case "Input":
        return (
          <div key={uid} className="flex items-center gap-2 p-2" style={{ marginLeft: indent }}>
            <div className="flex-1 flex items-center gap-2">
              <Code2 className="h-3 w-3 text-green-600" />
              <input
                type={element.input_type || "text"}
                placeholder={placeholder || "Input"}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm bg-white"
                disabled
              />
              <span className="text-xs text-gray-400">#{uid?.slice(-6)}</span>
            </div>
          </div>
        )

      case "Button":
        return (
          <div key={uid} className="flex items-center gap-2 p-2" style={{ marginLeft: indent }}>
            <Button
              size="sm"
              style={{
                backgroundColor: element.styles?.["background-color"] || "#1976d2",
                color: element.styles?.color || "#ffffff",
              }}
            >
              {text || "Botão"}
            </Button>
            <span className="text-xs text-gray-400">#{uid?.slice(-6)}</span>
          </div>
        )

      case "Image":
        return (
          <div key={uid} className="flex items-center gap-2 p-2" style={{ marginLeft: indent }}>
            <div
              className="bg-gray-200 rounded flex items-center justify-center text-gray-500 text-xs border"
              style={{
                width: element.styles?.width ? Number.parseInt(element.styles.width) : 80,
                height: element.styles?.height ? Number.parseInt(element.styles.height) : 80,
                borderRadius: element.styles?.["border-radius"] === "50%" ? "50%" : "8px",
              }}
            >
              🖼️
            </div>
            <span className="text-xs text-gray-400">#{uid?.slice(-6)}</span>
          </div>
        )

      case "RepeatingGroup":
        return (
          <div
            key={uid}
            className="border border-purple-200 rounded-lg p-3 bg-purple-50"
            style={{ marginLeft: indent }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Database className="h-4 w-4 text-purple-600" />
              <span className="font-medium text-sm text-purple-800">Repeating Group</span>
              <Badge variant="outline" className="text-xs">
                {element.type_of_content || "Data"}
              </Badge>
              <span className="text-xs text-gray-500">#{uid?.slice(-6)}</span>
            </div>
            <div className="text-xs text-purple-700 mb-2">Data Source: {element.data_source || "Not set"}</div>
            {elements && elements.length > 0 && (
              <div className="space-y-1">
                <div className="text-xs font-medium text-purple-700">Cell Template:</div>
                {elements.map((child: any) => renderBubbleElement(child, depth + 1))}
              </div>
            )}
          </div>
        )

      default:
        return (
          <div
            key={uid}
            className="flex items-center gap-2 p-2 bg-yellow-50 rounded border border-yellow-200"
            style={{ marginLeft: indent }}
          >
            <Zap className="h-3 w-3 text-yellow-600" />
            <span className="text-sm text-yellow-800">
              {type}: {text || placeholder || "Element"}
            </span>
            <span className="text-xs text-gray-400">#{uid?.slice(-6)}</span>
          </div>
        )
    }
  }

  const getPreviewWidth = () => {
    switch (previewMode) {
      case "mobile":
        return "max-w-sm"
      case "tablet":
        return "max-w-2xl"
      default:
        return "max-w-full"
    }
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!parsedJson) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        <div className="text-center">
          <Eye className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-500">Preview aparecerá aqui após gerar o JSON</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Preview Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Preview Bubble:</span>
          <div className="flex gap-1">
            <Button
              size="sm"
              variant={previewMode === "desktop" ? "default" : "outline"}
              onClick={() => setPreviewMode("desktop")}
            >
              <Monitor className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              variant={previewMode === "tablet" ? "default" : "outline"}
              onClick={() => setPreviewMode("tablet")}
            >
              <Tablet className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              variant={previewMode === "mobile" ? "default" : "outline"}
              onClick={() => setPreviewMode("mobile")}
            >
              <Smartphone className="h-3 w-3" />
            </Button>
          </div>
        </div>

        <div className="flex gap-2">
          <Badge variant="outline" className="bg-green-50 text-green-700">
            ✅ Bubble Compatible
          </Badge>
          {parsedJson.elements && <Badge variant="outline">{parsedJson.elements.length} elementos raiz</Badge>}
        </div>
      </div>

      {/* Preview Area */}
      <div className={`mx-auto transition-all duration-300 ${getPreviewWidth()}`}>
        <div className="border border-gray-200 rounded-lg p-4 bg-white min-h-[300px]">
          <div className="mb-4 p-2 bg-blue-50 rounded border border-blue-200">
            <div className="flex items-center gap-2 text-sm text-blue-800">
              <Database className="h-4 w-4" />
              <span className="font-medium">Estrutura Bubble Gerada</span>
            </div>
          </div>

          {parsedJson.elements && parsedJson.elements.length > 0 ? (
            <div className="space-y-2">{parsedJson.elements.map((element: any) => renderBubbleElement(element))}</div>
          ) : (
            <div className="text-center text-gray-500 py-8">Nenhum elemento encontrado</div>
          )}
        </div>
      </div>

      {/* Bubble Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Informações do JSON</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="font-medium">Versão:</span>
                <span>{parsedJson.version || "1.0"}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Elementos:</span>
                <span>{parsedJson.elements?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Workflows:</span>
                <span>{parsedJson.workflows?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Responsivo:</span>
                <span>{parsedJson.responsive_settings ? "✅ Sim" : "❌ Não"}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Como Importar no Bubble</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-xs text-gray-600">
              <div>1. Copie o JSON gerado</div>
              <div>2. No Bubble, vá para o Design</div>
              <div>3. Clique com botão direito na página</div>
              <div>4. Selecione "Paste" ou Ctrl+V</div>
              <div>5. Os elementos serão importados automaticamente</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
