"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { History, Clock, Layers, BarChart3, Trash2, Download, Eye } from "lucide-react"

interface GenerationResult {
  id: string
  description: string
  bubbleJson: any
  config: any
  timestamp: string
  complexity_score: number
  elements_count: number
}

interface GenerationHistoryProps {
  history: GenerationResult[]
  onLoadFromHistory: (result: GenerationResult) => void
  onClearHistory: () => void
}

export function GenerationHistory({ history, onLoadFromHistory, onClearHistory }: GenerationHistoryProps) {
  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getComplexityColor = (score: number) => {
    if (score < 30) return "bg-green-100 text-green-800"
    if (score < 60) return "bg-blue-100 text-blue-800"
    if (score < 90) return "bg-purple-100 text-purple-800"
    return "bg-red-100 text-red-800"
  }

  const getComplexityLabel = (score: number) => {
    if (score < 30) return "Simples"
    if (score < 60) return "Intermediário"
    if (score < 90) return "Avançado"
    return "Enterprise"
  }

  const downloadJson = (result: GenerationResult) => {
    const blob = new Blob([JSON.stringify(result.bubbleJson, null, 2)], {
      type: "application/json",
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `bubble-${result.id}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (history.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Histórico de Gerações
          </CardTitle>
          <CardDescription>Suas gerações anteriores aparecerão aqui</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <div className="text-center">
              <History className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Nenhuma geração no histórico</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Histórico de Gerações
              </CardTitle>
              <CardDescription>
                {history.length} geração{history.length !== 1 ? "ões" : ""} salva{history.length !== 1 ? "s" : ""}
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onClearHistory}
              className="text-red-600 hover:text-red-700 bg-transparent"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Limpar Histórico
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {history.map((result) => (
              <div
                key={result.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{formatDate(result.timestamp)}</span>
                      <Badge variant="secondary" className={`text-xs ${getComplexityColor(result.complexity_score)}`}>
                        {getComplexityLabel(result.complexity_score)}
                      </Badge>
                    </div>

                    <p className="text-sm font-medium mb-2 line-clamp-2">{result.description}</p>

                    <div className="flex items-center gap-4 text-xs text-gray-600">
                      <div className="flex items-center gap-1">
                        <Layers className="h-3 w-3" />
                        {result.elements_count} elementos
                      </div>
                      <div className="flex items-center gap-1">
                        <BarChart3 className="h-3 w-3" />
                        Score: {result.complexity_score}
                      </div>
                      <div className="flex items-center gap-1">
                        <span>Framework: {result.config.framework || "bubble"}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-2">
                      {result.config.includeLogic && (
                        <Badge variant="outline" className="text-xs">
                          Lógica
                        </Badge>
                      )}
                      {result.config.includeWorkflows && (
                        <Badge variant="outline" className="text-xs">
                          Workflows
                        </Badge>
                      )}
                      {result.config.includeResponsive && (
                        <Badge variant="outline" className="text-xs">
                          Responsivo
                        </Badge>
                      )}
                      {result.config.includeDataBinding && (
                        <Badge variant="outline" className="text-xs">
                          Data Binding
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <Button size="sm" variant="outline" onClick={() => onLoadFromHistory(result)}>
                      <Eye className="h-3 w-3 mr-1" />
                      Carregar
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => downloadJson(result)}>
                      <Download className="h-3 w-3 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Estatísticas do Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="text-center">
              <div className="font-bold text-lg text-blue-600">{history.length}</div>
              <div className="text-gray-600">Total de Gerações</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg text-green-600">
                {Math.round(history.reduce((acc, h) => acc + h.elements_count, 0) / history.length) || 0}
              </div>
              <div className="text-gray-600">Média de Elementos</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg text-purple-600">
                {Math.round(history.reduce((acc, h) => acc + h.complexity_score, 0) / history.length) || 0}
              </div>
              <div className="text-gray-600">Score Médio</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg text-orange-600">
                {history.filter((h) => h.config.includeWorkflows).length}
              </div>
              <div className="text-gray-600">Com Workflows</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
