"use client"

import { useState, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, AlertTriangle, RefreshCw, FileText, Code2 } from "lucide-react"

interface JsonEditorProps {
  value: string
  onChange: (value: string) => void
}

export function JsonEditor({ value, onChange }: JsonEditorProps) {
  const [isValid, setIsValid] = useState(true)
  const [error, setError] = useState("")
  const [warnings, setWarnings] = useState<string[]>([])
  const [stats, setStats] = useState({
    lines: 0,
    characters: 0,
    elements: 0,
    workflows: 0,
    bubbleCompatible: false,
  })

  useEffect(() => {
    validateBubbleJson(value)
    updateStats(value)
  }, [value])

  const validateBubbleJson = (jsonString: string) => {
    if (!jsonString.trim()) {
      setIsValid(true)
      setError("")
      setWarnings([])
      return
    }

    try {
      const parsed = JSON.parse(jsonString)
      setIsValid(true)
      setError("")

      // Validação específica para formato Bubble nativo
      const validationResult = validateBubbleStructure(parsed)
      setWarnings(validationResult.warnings)

      if (validationResult.errors.length > 0) {
        setError(validationResult.errors[0])
        setIsValid(false)
      }
    } catch (err) {
      setIsValid(false)
      setError(err instanceof Error ? err.message : "JSON inválido")
      setWarnings([])
    }
  }

  const validateBubbleStructure = (json: any) => {
    const errors: string[] = []
    const warnings: string[] = []

    // Verificar se é um JSON do Bubble (formato nativo)
    if (json.elements && Array.isArray(json.elements)) {
      // Formato nativo do Bubble - validar elementos
      const elementValidation = validateBubbleElements(json.elements)
      errors.push(...elementValidation.errors)
      warnings.push(...elementValidation.warnings)

      // Verificar estrutura raiz
      if (json.version) {
        warnings.push(`Versão detectada: ${json.version}`)
      }

      if (json.workflows && Array.isArray(json.workflows)) {
        warnings.push(`${json.workflows.length} workflow(s) encontrado(s)`)
      }

      if (json.responsive_settings) {
        warnings.push("Configurações responsivas detectadas")
      }
    } else if (json.type && json.data) {
      // Formato antigo - converter sugestão
      warnings.push("Formato antigo detectado. Considere usar o formato nativo do Bubble.")
    } else if (json.uid && json.type) {
      // Elemento individual do Bubble
      const elementValidation = validateBubbleElements([json])
      errors.push(...elementValidation.errors)
      warnings.push(...elementValidation.warnings)
      warnings.push("Elemento individual detectado")
    } else if (json.element_definitions) {
      warnings.push("Novo formato de JSON detectado")
    } else {
      // Estrutura desconhecida
      warnings.push("Estrutura JSON não reconhecida como formato Bubble padrão")
    }

    return { errors, warnings }
  }

  const validateBubbleElements = (elements: any[]) => {
    const errors: string[] = []
    const warnings: string[] = []

    elements.forEach((element, index) => {
      // Validar propriedades obrigatórias do elemento Bubble
      if (!element.type) {
        errors.push(`Elemento ${index + 1}: propriedade 'type' é obrigatória`)
      }

      if (!element.uid) {
        warnings.push(`Elemento ${index + 1}: 'uid' não encontrado (será gerado automaticamente)`)
      }

      // Validar tipos conhecidos do Bubble
      const validTypes = [
        "Group",
        "Text",
        "Input",
        "Button",
        "Image",
        "RepeatingGroup",
        "Dropdown",
        "Checkbox",
        "RadioButton",
        "DatePicker",
        "FileUploader",
        "Map",
        "Chart",
        "Video",
        "Audio",
        "Shape",
        "Icon",
        "Link",
      ]

      if (element.type && !validTypes.includes(element.type)) {
        warnings.push(`Elemento ${index + 1}: tipo '${element.type}' pode não ser reconhecido pelo Bubble`)
      }

      // Validar elementos aninhados
      if (element.elements && Array.isArray(element.elements)) {
        const nestedValidation = validateBubbleElements(element.elements)
        errors.push(...nestedValidation.errors)
        warnings.push(...nestedValidation.warnings)
      }

      // Validações específicas por tipo
      if (element.type === "Group" && element.elements && element.elements.length === 0) {
        warnings.push(`Grupo ${index + 1}: está vazio`)
      }

      if (element.type === "RepeatingGroup" && !element.data_source) {
        warnings.push(`RepeatingGroup ${index + 1}: 'data_source' não definido`)
      }
    })

    return { errors, warnings }
  }

  const updateStats = (jsonString: string) => {
    const lines = jsonString.split("\n").length
    const characters = jsonString.length
    let elements = 0
    let workflows = 0
    let bubbleCompatible = false

    try {
      const parsed = JSON.parse(jsonString)

      if (parsed.elements && Array.isArray(parsed.elements)) {
        elements = countElements(parsed.elements)
        bubbleCompatible = true
      } else if (parsed.uid && parsed.type) {
        elements = 1
        bubbleCompatible = true
      } else if (parsed.element_definitions) {
        elements = countElements(Object.values(parsed.element_definitions))
        workflows = parsed.workflows ? Object.keys(parsed.workflows).length : 0
        bubbleCompatible = true
      }

      if (parsed.workflows && Array.isArray(parsed.workflows)) {
        workflows = parsed.workflows.length
      }
    } catch {
      // Ignore parsing errors for stats
    }

    setStats({ lines, characters, elements, workflows, bubbleCompatible })
  }

  const countElements = (elements: any[]): number => {
    let count = 0
    elements.forEach((element) => {
      count += 1
      if (element.elements && Array.isArray(element.elements)) {
        count += countElements(element.elements)
      }
    })
    return count
  }

  const handleChange = (newValue: string) => {
    onChange(newValue)
  }

  const formatJson = () => {
    try {
      const parsed = JSON.parse(value)
      const formatted = JSON.stringify(parsed, null, 2)
      onChange(formatted)
    } catch (err) {
      setError("Não é possível formatar JSON inválido")
    }
  }

  const minifyJson = () => {
    try {
      const parsed = JSON.parse(value)
      const minified = JSON.stringify(parsed)
      onChange(minified)
    } catch (err) {
      setError("Não é possível minificar JSON inválido")
    }
  }

  return (
    <div className="space-y-4">
      {/* Header com status e controles */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            {isValid ? (
              <CheckCircle className="h-4 w-4 text-green-500" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-red-500" />
            )}
            <span className="text-sm font-medium">{isValid ? "JSON Válido" : "JSON Inválido"}</span>
          </div>

          {stats.bubbleCompatible && (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              ✅ Bubble Compatible
            </Badge>
          )}
        </div>

        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={formatJson} disabled={!isValid}>
            <Code2 className="h-3 w-3 mr-1" />
            Formatar
          </Button>
          <Button size="sm" variant="outline" onClick={minifyJson} disabled={!isValid}>
            <RefreshCw className="h-3 w-3 mr-1" />
            Minificar
          </Button>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="flex gap-4">
        <Badge variant="outline" className="flex items-center gap-1">
          <FileText className="h-3 w-3" />
          {stats.lines} linhas
        </Badge>
        <Badge variant="outline">{stats.characters} caracteres</Badge>
        <Badge variant="outline">{stats.elements} elementos</Badge>
        {stats.workflows > 0 && (
          <Badge variant="outline" className="bg-blue-50 text-blue-700">
            {stats.workflows} workflows
          </Badge>
        )}
      </div>

      {/* Alertas de erro */}
      {!isValid && error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Avisos */}
      {warnings.length > 0 && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-1">
              <div className="font-medium">Avisos de Validação:</div>
              <ul className="text-sm space-y-1">
                {warnings.map((warning, index) => (
                  <li key={index}>• {warning}</li>
                ))}
              </ul>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Editor de texto */}
      <div className="relative">
        <Textarea
          value={value}
          onChange={(e) => handleChange(e.target.value)}
          className="font-mono text-sm min-h-[400px] resize-none"
          placeholder="Cole ou edite o JSON do Bubble aqui..."
        />

        {/* Indicador de linha/coluna */}
        <div className="absolute bottom-2 right-2 text-xs text-gray-500 bg-white px-2 py-1 rounded border">
          Ln {value.split("\n").length}, Col {value.length - value.lastIndexOf("\n")}
        </div>
      </div>

      {/* Dicas de uso */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-medium text-blue-900 mb-2">💡 Dicas do Editor:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-blue-800">
          <div>• Use "Formatar" para organizar o JSON</div>
          <div>• "Minificar" remove espaços desnecessários</div>
          <div>• Elementos precisam ter 'type' obrigatório</div>
          <div>• 'uid' será gerado se não fornecido</div>
        </div>
      </div>

      {/* Estrutura detectada */}
      {isValid && value.trim() && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <h4 className="font-medium text-gray-900 mb-2">📋 Estrutura Detectada:</h4>
          <div className="text-sm text-gray-700">
            {stats.bubbleCompatible ? (
              <div className="space-y-1">
                <div>✅ Formato nativo do Bubble detectado</div>
                <div>📊 {stats.elements} elemento(s) total</div>
                {stats.workflows > 0 && <div>⚡ {stats.workflows} workflow(s)</div>}
                <div>🚀 Pronto para importar no Bubble</div>
              </div>
            ) : (
              <div>⚠️ Estrutura JSON genérica (pode não ser compatível com Bubble)</div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
