"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  FileText,
  Table,
  ShoppingCart,
  Users,
  BarChart3,
  MessageSquare,
  Calendar,
  Settings,
} from "lucide-react"

interface Template {
  id: string
  name: string
  description: string
  icon: any
  category: string
  complexity: "simple" | "intermediate" | "advanced" | "enterprise"
  features: string[]
  preview_description: string
  config?: any
}

const templates: Template[] = [
  {
    id: "dashboard-analytics",
    name: "Dashboard Analytics",
    description: "Dashboard completo com métricas, gráficos e filtros em tempo real",
    icon: LayoutDashboard,
    category: "Analytics",
    complexity: "advanced",
    features: ["Gráficos Interativos", "Filtros Avançados", "Tempo Real", "Responsivo"],
    preview_description:
      "Um dashboard de analytics com cards de métricas, gráficos de linha e pizza, filtros por data, tabela de dados com paginação e atualização em tempo real",
    config: {
      includeLogic: true,
      includeWorkflows: true,
      includeResponsive: true,
      includeDataBinding: true,
    },
  },
  {
    id: "ecommerce-product",
    name: "Catálogo E-commerce",
    description: "Sistema completo de produtos com carrinho e checkout",
    icon: ShoppingCart,
    category: "E-commerce",
    complexity: "enterprise",
    features: ["Carrinho", "Pagamento", "Filtros", "Wishlist", "Reviews"],
    preview_description:
      "Uma página de produtos com grid responsivo, filtros por categoria e preço, carrinho de compras, sistema de avaliações e checkout integrado",
    config: {
      complexity: "enterprise",
      includeLogic: true,
      includeWorkflows: true,
      includeDataBinding: true,
    },
  },
  {
    id: "user-management",
    name: "Gerenciamento de Usuários",
    description: "Sistema CRUD completo para gerenciar usuários",
    icon: Users,
    category: "Admin",
    complexity: "advanced",
    features: ["CRUD", "Busca", "Filtros", "Paginação", "Bulk Actions"],
    preview_description:
      "Uma interface administrativa com tabela de usuários, busca avançada, filtros múltiplos, ações em lote, formulários de edição e sistema de permissões",
    config: {
      includeLogic: true,
      includeWorkflows: true,
      includeDataBinding: true,
    },
  },
  {
    id: "multi-step-form",
    name: "Formulário Multi-etapa",
    description: "Formulário complexo com validações e upload de arquivos",
    icon: FileText,
    category: "Forms",
    complexity: "intermediate",
    features: ["Multi-step", "Validação", "Upload", "Progress", "Auto-save"],
    preview_description:
      "Um formulário de cadastro em múltiplas etapas com barra de progresso, validações em tempo real, upload de documentos e salvamento automático",
    config: {
      includeLogic: true,
      includeWorkflows: false,
      includeResponsive: true,
    },
  },
  {
    id: "data-table-advanced",
    name: "Tabela de Dados Avançada",
    description: "Tabela com ordenação, filtros e exportação",
    icon: Table,
    category: "Data",
    complexity: "intermediate",
    features: ["Sorting", "Filtering", "Export", "Pagination", "Bulk Select"],
    preview_description:
      "Uma tabela de dados com ordenação por colunas, filtros avançados, seleção múltipla, paginação inteligente e exportação para Excel/PDF",
    config: {
      includeLogic: true,
      includeDataBinding: true,
    },
  },
  {
    id: "chat-interface",
    name: "Interface de Chat",
    description: "Sistema de mensagens em tempo real",
    icon: MessageSquare,
    category: "Communication",
    complexity: "advanced",
    features: ["Real-time", "Emoji", "File Share", "Typing Indicator", "Online Status"],
    preview_description:
      "Uma interface de chat com mensagens em tempo real, indicador de digitação, compartilhamento de arquivos, emojis e status online",
    config: {
      includeLogic: true,
      includeWorkflows: true,
      includeDataBinding: true,
    },
  },
  {
    id: "calendar-booking",
    name: "Sistema de Agendamento",
    description: "Calendário com reservas e notificações",
    icon: Calendar,
    category: "Scheduling",
    complexity: "advanced",
    features: ["Calendar", "Booking", "Notifications", "Recurring", "Conflicts"],
    preview_description:
      "Um sistema de agendamento com calendário interativo, reserva de horários, detecção de conflitos, eventos recorrentes e notificações automáticas",
    config: {
      includeLogic: true,
      includeWorkflows: true,
      includeDataBinding: true,
    },
  },
  {
    id: "settings-panel",
    name: "Painel de Configurações",
    description: "Interface completa de configurações do sistema",
    icon: Settings,
    category: "Admin",
    complexity: "intermediate",
    features: ["Tabs", "Forms", "Validation", "Preview", "Reset"],
    preview_description:
      "Um painel de configurações com abas organizadas, formulários de configuração, preview das mudanças, validações e opção de reset",
    config: {
      includeLogic: true,
      includeResponsive: true,
    },
  },
]

interface TemplateSelectorProps {
  onSelectTemplate: (template: Template) => void
}

export function TemplateSelector({ onSelectTemplate }: TemplateSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  const categories = ["all", ...Array.from(new Set(templates.map((t) => t.category)))]

  const filteredTemplates =
    selectedCategory === "all" ? templates : templates.filter((t) => t.category === selectedCategory)

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case "simple":
        return "bg-green-100 text-green-800"
      case "intermediate":
        return "bg-blue-100 text-blue-800"
      case "advanced":
        return "bg-purple-100 text-purple-800"
      case "enterprise":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Templates Profissionais
        </CardTitle>
        <CardDescription>Escolha um template para começar rapidamente</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Category Filter */}
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              size="sm"
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
            >
              {category === "all" ? "Todos" : category}
            </Button>
          ))}
        </div>

        {/* Templates Grid */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filteredTemplates.map((template) => {
            const IconComponent = template.icon
            return (
              <div
                key={template.id}
                className="border border-gray-200 rounded-lg p-3 hover:border-blue-300 transition-colors cursor-pointer"
                onClick={() => onSelectTemplate(template)}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <IconComponent className="h-4 w-4 text-blue-600" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm">{template.name}</h4>
                      <Badge variant="secondary" className={`text-xs ${getComplexityColor(template.complexity)}`}>
                        {template.complexity}
                      </Badge>
                    </div>

                    <p className="text-xs text-gray-600 mb-2">{template.description}</p>

                    <div className="flex flex-wrap gap-1">
                      {template.features.slice(0, 3).map((feature) => (
                        <Badge key={feature} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                      {template.features.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{template.features.length - 3}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
