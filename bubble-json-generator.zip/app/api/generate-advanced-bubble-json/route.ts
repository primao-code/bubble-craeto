import { type NextRequest, NextResponse } from "next/server"

interface GenerationConfig {
  complexity: "simple" | "intermediate" | "advanced" | "enterprise"
  includeLogic: boolean
  includeWorkflows: boolean
  includeResponsive: boolean
  includeAnimations: boolean
  includeDataBinding: boolean
  targetDevice: "desktop" | "mobile" | "both"
  framework: "bubble" | "bubble-native" | "bubble-api"
}

// Gerador compatível com formato Bubble real
class BubbleCompatibleGenerator {
  private generateUniqueId(): string {
    return Math.random().toString(36).substr(2, 16)
  }

  private createBubbleElement(type: string, properties: any = {}) {
    const baseElement = {
      uid: this.generateUniqueId(),
      type: type,
      rank: 0,
      styles: {},
      ...properties,
    }

    // Adicionar propriedades específicas por tipo
    switch (type) {
      case "Group":
        return {
          ...baseElement,
          container_layout_type: properties.layout || "column",
          gap: properties.gap || 10,
          elements: properties.elements || [],
        }
      case "Text":
        return {
          ...baseElement,
          text: properties.text || "Texto",
          styles: {
            ...baseElement.styles,
            "font-size": properties.fontSize || "14px",
            "font-weight": properties.fontWeight || "400",
            color: properties.color || "#000000",
          },
        }
      case "Input":
        return {
          ...baseElement,
          placeholder: properties.placeholder || "",
          input_type: properties.inputType || "text",
          styles: {
            ...baseElement.styles,
            width: properties.width || "200px",
            height: properties.height || "40px",
          },
        }
      case "Button":
        return {
          ...baseElement,
          text: properties.text || "Botão",
          styles: {
            ...baseElement.styles,
            "background-color": properties.backgroundColor || "#1976d2",
            color: properties.textColor || "#ffffff",
            "border-radius": properties.borderRadius || "4px",
            width: properties.width || "auto",
            height: properties.height || "40px",
          },
        }
      case "Image":
        return {
          ...baseElement,
          dynamic_image: properties.dynamicImage || false,
          styles: {
            ...baseElement.styles,
            width: properties.width || "100px",
            height: properties.height || "100px",
            "border-radius": properties.borderRadius || "0px",
          },
        }
      case "RepeatingGroup":
        return {
          ...baseElement,
          data_source: properties.dataSource || "",
          type_of_content: properties.contentType || "text",
          layout_type: properties.layoutType || "full_list",
          number_of_rows: properties.rows || 5,
          number_of_columns: properties.columns || 1,
          elements: properties.elements || [],
        }
      default:
        return baseElement
    }
  }

  generateUserCard() {
    const cardGroup = this.createBubbleElement("Group", {
      layout: "row",
      gap: 15,
      elements: [],
    })

    // Foto do usuário
    const userImage = this.createBubbleElement("Image", {
      width: "80px",
      height: "80px",
      borderRadius: "50%",
    })

    // Grupo de informações
    const infoGroup = this.createBubbleElement("Group", {
      layout: "column",
      gap: 5,
      elements: [],
    })

    // Nome do usuário
    const userName = this.createBubbleElement("Text", {
      text: "Nome do Usuário",
      fontSize: "18px",
      fontWeight: "600",
    })

    // Email do usuário
    const userEmail = this.createBubbleElement("Text", {
      text: "usuario@email.com",
      fontSize: "14px",
      color: "#666666",
    })

    // Montar estrutura
    infoGroup.elements = [userName, userEmail]
    cardGroup.elements = [userImage, infoGroup]

    return {
      elements: [cardGroup],
      workflows: [],
      styles: {},
    }
  }

  generateLoginForm() {
    const formGroup = this.createBubbleElement("Group", {
      layout: "column",
      gap: 20,
      elements: [],
    })

    // Título
    const title = this.createBubbleElement("Text", {
      text: "Login",
      fontSize: "24px",
      fontWeight: "700",
    })

    // Input Email
    const emailInput = this.createBubbleElement("Input", {
      placeholder: "Digite seu email",
      inputType: "email",
      width: "300px",
    })

    // Input Senha
    const passwordInput = this.createBubbleElement("Input", {
      placeholder: "Digite sua senha",
      inputType: "password",
      width: "300px",
    })

    // Botão Login
    const loginButton = this.createBubbleElement("Button", {
      text: "Entrar",
      backgroundColor: "#1976d2",
      width: "300px",
    })

    // Link "Esqueci minha senha"
    const forgotLink = this.createBubbleElement("Text", {
      text: "Esqueci minha senha?",
      fontSize: "12px",
      color: "#1976d2",
    })

    formGroup.elements = [title, emailInput, passwordInput, loginButton, forgotLink]

    return {
      elements: [formGroup],
      workflows: [],
      styles: {},
    }
  }

  generateDashboard(config: GenerationConfig) {
    const mainGroup = this.createBubbleElement("Group", {
      layout: "column",
      gap: 20,
      elements: [],
    })

    // Header
    const header = this.createBubbleElement("Group", {
      layout: "row",
      gap: 0,
      elements: [],
    })

    const dashboardTitle = this.createBubbleElement("Text", {
      text: "Dashboard",
      fontSize: "28px",
      fontWeight: "700",
    })

    header.elements = [dashboardTitle]

    // Métricas Row
    const metricsRow = this.createBubbleElement("Group", {
      layout: "row",
      gap: 16,
      elements: [],
    })

    // Card de Vendas
    const salesCard = this.createBubbleElement("Group", {
      layout: "column",
      gap: 8,
      elements: [],
    })

    const salesValue = this.createBubbleElement("Text", {
      text: "R$ 12.345",
      fontSize: "32px",
      fontWeight: "700",
      color: "#1976d2",
    })

    const salesLabel = this.createBubbleElement("Text", {
      text: "Total de Vendas",
      fontSize: "14px",
      color: "#666666",
    })

    salesCard.elements = [salesValue, salesLabel]

    // Card de Crescimento
    const growthCard = this.createBubbleElement("Group", {
      layout: "column",
      gap: 8,
      elements: [],
    })

    const growthValue = this.createBubbleElement("Text", {
      text: "+23.5%",
      fontSize: "32px",
      fontWeight: "700",
      color: "#4caf50",
    })

    const growthLabel = this.createBubbleElement("Text", {
      text: "Crescimento",
      fontSize: "14px",
      color: "#666666",
    })

    growthCard.elements = [growthValue, growthLabel]

    metricsRow.elements = [salesCard, growthCard]

    // Tabela de dados (se complexidade avançada)
    const elements = [header, metricsRow]

    if (config.complexity === "advanced" || config.complexity === "enterprise") {
      const dataTable = this.createBubbleElement("RepeatingGroup", {
        dataSource: "Search for Users",
        contentType: "User",
        layoutType: "full_list",
        rows: 5,
        elements: [],
      })

      // Célula da tabela
      const tableCell = this.createBubbleElement("Group", {
        layout: "row",
        gap: 20,
        elements: [],
      })

      const cellName = this.createBubbleElement("Text", {
        text: "Current cell's User's Name",
        fontSize: "14px",
      })

      const cellEmail = this.createBubbleElement("Text", {
        text: "Current cell's User's Email",
        fontSize: "14px",
        color: "#666666",
      })

      const cellStatus = this.createBubbleElement("Text", {
        text: "Ativo",
        fontSize: "12px",
        color: "#4caf50",
      })

      tableCell.elements = [cellName, cellEmail, cellStatus]
      dataTable.elements = [tableCell]

      elements.push(dataTable)
    }

    mainGroup.elements = elements

    return {
      elements: [mainGroup],
      workflows: config.includeWorkflows ? this.generateWorkflows() : [],
      styles: {},
    }
  }

  generateAdvancedForm(config: GenerationConfig) {
    const formGroup = this.createBubbleElement("Group", {
      layout: "column",
      gap: 16,
      elements: [],
    })

    // Título do formulário
    const formTitle = this.createBubbleElement("Text", {
      text: "Cadastro Completo",
      fontSize: "24px",
      fontWeight: "700",
    })

    // Seção dados pessoais
    const personalSection = this.createBubbleElement("Group", {
      layout: "column",
      gap: 12,
      elements: [],
    })

    const sectionTitle = this.createBubbleElement("Text", {
      text: "Dados Pessoais",
      fontSize: "18px",
      fontWeight: "600",
    })

    // Row com nome e sobrenome
    const nameRow = this.createBubbleElement("Group", {
      layout: "row",
      gap: 12,
      elements: [],
    })

    const firstNameInput = this.createBubbleElement("Input", {
      placeholder: "Nome",
      width: "200px",
    })

    const lastNameInput = this.createBubbleElement("Input", {
      placeholder: "Sobrenome",
      width: "200px",
    })

    nameRow.elements = [firstNameInput, lastNameInput]

    // Email
    const emailInput = this.createBubbleElement("Input", {
      placeholder: "Email",
      inputType: "email",
      width: "412px",
    })

    // Telefone
    const phoneInput = this.createBubbleElement("Input", {
      placeholder: "Telefone",
      inputType: "tel",
      width: "412px",
    })

    personalSection.elements = [sectionTitle, nameRow, emailInput, phoneInput]

    // Seção endereço (se complexidade avançada)
    const elements = [formTitle, personalSection]

    if (config.complexity === "advanced" || config.complexity === "enterprise") {
      const addressSection = this.createBubbleElement("Group", {
        layout: "column",
        gap: 12,
        elements: [],
      })

      const addressTitle = this.createBubbleElement("Text", {
        text: "Endereço",
        fontSize: "18px",
        fontWeight: "600",
      })

      const streetInput = this.createBubbleElement("Input", {
        placeholder: "Rua",
        width: "412px",
      })

      const addressRow = this.createBubbleElement("Group", {
        layout: "row",
        gap: 12,
        elements: [],
      })

      const numberInput = this.createBubbleElement("Input", {
        placeholder: "Número",
        width: "100px",
      })

      const cityInput = this.createBubbleElement("Input", {
        placeholder: "Cidade",
        width: "200px",
      })

      const stateInput = this.createBubbleElement("Input", {
        placeholder: "Estado",
        width: "100px",
      })

      addressRow.elements = [numberInput, cityInput, stateInput]
      addressSection.elements = [addressTitle, streetInput, addressRow]

      elements.push(addressSection)
    }

    // Botões de ação
    const actionsRow = this.createBubbleElement("Group", {
      layout: "row",
      gap: 12,
      elements: [],
    })

    const cancelButton = this.createBubbleElement("Button", {
      text: "Cancelar",
      backgroundColor: "#f5f5f5",
      textColor: "#333333",
      width: "120px",
    })

    const submitButton = this.createBubbleElement("Button", {
      text: "Salvar",
      backgroundColor: "#4caf50",
      width: "120px",
    })

    actionsRow.elements = [cancelButton, submitButton]
    elements.push(actionsRow)

    formGroup.elements = elements

    return {
      elements: [formGroup],
      workflows: config.includeWorkflows ? this.generateFormWorkflows() : [],
      styles: {},
    }
  }

  generateDataTable(config: GenerationConfig) {
    const tableContainer = this.createBubbleElement("Group", {
      layout: "column",
      gap: 16,
      elements: [],
    })

    // Header da tabela
    const tableHeader = this.createBubbleElement("Group", {
      layout: "row",
      gap: 0,
      elements: [],
    })

    const tableTitle = this.createBubbleElement("Text", {
      text: "Gerenciar Usuários",
      fontSize: "20px",
      fontWeight: "600",
    })

    const addButton = this.createBubbleElement("Button", {
      text: "Adicionar",
      backgroundColor: "#1976d2",
      width: "100px",
    })

    tableHeader.elements = [tableTitle, addButton]

    // Filtros (se habilitado)
    const elements = [tableHeader]

    if (config.complexity === "advanced" || config.complexity === "enterprise") {
      const filtersRow = this.createBubbleElement("Group", {
        layout: "row",
        gap: 12,
        elements: [],
      })

      const searchInput = this.createBubbleElement("Input", {
        placeholder: "Buscar usuários...",
        width: "250px",
      })

      const statusFilter = this.createBubbleElement("Button", {
        text: "Todos os Status",
        backgroundColor: "#f5f5f5",
        textColor: "#333333",
        width: "150px",
      })

      filtersRow.elements = [searchInput, statusFilter]
      elements.push(filtersRow)
    }

    // Tabela principal
    const dataTable = this.createBubbleElement("RepeatingGroup", {
      dataSource: "Search for Users",
      contentType: "User",
      layoutType: "full_list",
      rows: 10,
      elements: [],
    })

    // Header da tabela
    const tableHeaderRow = this.createBubbleElement("Group", {
      layout: "row",
      gap: 20,
      elements: [],
    })

    const headerName = this.createBubbleElement("Text", {
      text: "Nome",
      fontSize: "14px",
      fontWeight: "600",
    })

    const headerEmail = this.createBubbleElement("Text", {
      text: "Email",
      fontSize: "14px",
      fontWeight: "600",
    })

    const headerStatus = this.createBubbleElement("Text", {
      text: "Status",
      fontSize: "14px",
      fontWeight: "600",
    })

    const headerActions = this.createBubbleElement("Text", {
      text: "Ações",
      fontSize: "14px",
      fontWeight: "600",
    })

    tableHeaderRow.elements = [headerName, headerEmail, headerStatus, headerActions]

    // Linha de dados
    const dataRow = this.createBubbleElement("Group", {
      layout: "row",
      gap: 20,
      elements: [],
    })

    const cellName = this.createBubbleElement("Text", {
      text: "Current cell's User's Name",
      fontSize: "14px",
    })

    const cellEmail = this.createBubbleElement("Text", {
      text: "Current cell's User's Email",
      fontSize: "14px",
    })

    const cellStatus = this.createBubbleElement("Text", {
      text: "Ativo",
      fontSize: "12px",
      color: "#4caf50",
    })

    const actionsGroup = this.createBubbleElement("Group", {
      layout: "row",
      gap: 8,
      elements: [],
    })

    const editButton = this.createBubbleElement("Button", {
      text: "Editar",
      backgroundColor: "#ff9800",
      width: "60px",
    })

    const deleteButton = this.createBubbleElement("Button", {
      text: "Excluir",
      backgroundColor: "#f44336",
      width: "60px",
    })

    actionsGroup.elements = [editButton, deleteButton]
    dataRow.elements = [cellName, cellEmail, cellStatus, actionsGroup]

    dataTable.elements = [tableHeaderRow, dataRow]
    elements.push(dataTable)

    tableContainer.elements = elements

    return {
      elements: [tableContainer],
      workflows: config.includeWorkflows ? this.generateTableWorkflows() : [],
      styles: {},
    }
  }

  generateWorkflows() {
    return [
      {
        name: "Load Dashboard Data",
        trigger: "Page is loaded",
        actions: [
          {
            type: "Make changes to thing",
            thing: "Current User",
            field: "last_login",
            value: "Current date/time",
          },
        ],
      },
    ]
  }

  generateFormWorkflows() {
    return [
      {
        name: "Submit Form",
        trigger: "An element is clicked",
        element: "Button Salvar",
        actions: [
          {
            type: "Create a new thing",
            thing: "User",
            fields: {
              name: "Input Nome's value",
              email: "Input Email's value",
              phone: "Input Telefone's value",
            },
          },
          {
            type: "Navigate to page",
            page: "success",
          },
        ],
      },
    ]
  }

  generateTableWorkflows() {
    return [
      {
        name: "Delete User",
        trigger: "An element is clicked",
        element: "Button Excluir",
        actions: [
          {
            type: "Delete a thing",
            thing: "Current cell's User",
          },
        ],
      },
    ]
  }

  generate(description: string, config: GenerationConfig) {
    const lowerDesc = description.toLowerCase()

    // Detectar tipo baseado na descrição
    if (lowerDesc.includes("login") || lowerDesc.includes("entrar")) {
      return this.generateLoginForm()
    } else if (lowerDesc.includes("card") && lowerDesc.includes("usuário")) {
      return this.generateUserCard()
    } else if (lowerDesc.includes("dashboard") || lowerDesc.includes("painel")) {
      return this.generateDashboard(config)
    } else if (lowerDesc.includes("formulário") || lowerDesc.includes("cadastro")) {
      return this.generateAdvancedForm(config)
    } else if (lowerDesc.includes("tabela") || lowerDesc.includes("lista") || lowerDesc.includes("gerenciar")) {
      return this.generateDataTable(config)
    } else {
      // Padrão: formulário simples
      return this.generateLoginForm()
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { description, config, template } = body

    if (!description || typeof description !== "string") {
      return NextResponse.json({ error: "Descrição é obrigatória" }, { status: 400 })
    }

    // Simula delay de processamento
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const generator = new BubbleCompatibleGenerator()
    const result = generator.generate(description, config)

    // Formato final compatível com Bubble
    const bubbleJson = {
      version: "1.0",
      elements: result.elements,
      workflows: result.workflows,
      styles: result.styles,
      responsive_settings: config.includeResponsive
        ? {
            mobile: { max_width: "768px" },
            tablet: { max_width: "1024px" },
          }
        : {},
    }

    // Calcular métricas
    const elementsCount = countElements(result.elements)
    const complexityScore = calculateComplexityScore(elementsCount, config)

    return NextResponse.json({
      success: true,
      bubbleJson,
      metadata: {
        description,
        config,
        generated_at: new Date().toISOString(),
        version: "2.1",
        elements_count: elementsCount,
        complexity_score: complexityScore,
        estimated_development_time: `${Math.ceil(complexityScore / 10)} horas`,
        bubble_compatible: true,
        format: "Bubble Native JSON",
      },
    })
  } catch (error) {
    console.error("Erro ao processar requisição:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}

function countElements(elements: any[]): number {
  let count = 0
  elements.forEach((element) => {
    count += 1
    if (element.elements && Array.isArray(element.elements)) {
      count += countElements(element.elements)
    }
  })
  return count
}

function calculateComplexityScore(elementsCount: number, config: GenerationConfig): number {
  let score = elementsCount * 3

  if (config.includeWorkflows) score += 20
  if (config.includeLogic) score += 15
  if (config.includeDataBinding) score += 10
  if (config.includeResponsive) score += 5

  switch (config.complexity) {
    case "enterprise":
      score *= 2
      break
    case "advanced":
      score *= 1.5
      break
    case "intermediate":
      score *= 1.2
      break
  }

  return Math.round(score)
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
