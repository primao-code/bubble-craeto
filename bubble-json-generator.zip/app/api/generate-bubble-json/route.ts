import { type NextRequest, NextResponse } from "next/server"

// Simulação de diferentes tipos de elementos baseados na descrição
function generateBubbleJson(description: string) {
  const lowerDesc = description.toLowerCase()

  // Detecta o tipo de elemento baseado em palavras-chave
  if (lowerDesc.includes("card") && (lowerDesc.includes("usuário") || lowerDesc.includes("user"))) {
    return generateUserCard()
  } else if (lowerDesc.includes("botão") || lowerDesc.includes("button")) {
    return generateButton(description)
  } else if (lowerDesc.includes("formulário") || lowerDesc.includes("form")) {
    return generateForm()
  } else if (lowerDesc.includes("lista") || lowerDesc.includes("list")) {
    return generateList()
  } else {
    return generateGenericGroup(description)
  }
}

function generateUserCard() {
  return {
    type: "Group",
    data: {
      name: "CardUsuario",
      bubble_id: `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      layout_mode: "row",
      gap: 15,
      padding: 20,
      background_color: "#ffffff",
      border_radius: 12,
      shadow: "0 2px 8px rgba(0,0,0,0.1)",
      elements: [
        {
          type: "Image",
          data: {
            name: "FotoUsuario",
            bubble_id: `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            width: 80,
            height: 80,
            border_radius: "50%",
            url: "https://via.placeholder.com/80",
          },
        },
        {
          type: "Group",
          data: {
            name: "InfoUsuario",
            bubble_id: `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            layout_mode: "column",
            gap: 5,
            elements: [
              {
                type: "Text",
                data: {
                  name: "NomeUsuario",
                  bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                  text: "Nome do Usuário",
                  font_size: 20,
                  font_weight: "bold",
                  color: "#333333",
                },
              },
              {
                type: "Text",
                data: {
                  name: "EmailUsuario",
                  bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                  text: "email@exemplo.com",
                  font_size: 14,
                  color: "#666666",
                },
              },
            ],
          },
        },
      ],
    },
  }
}

function generateButton(description: string) {
  return {
    type: "Button",
    data: {
      name: "BotaoCustom",
      bubble_id: `btn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      text: "Clique Aqui",
      width: 200,
      height: 45,
      background_color: "#3b82f6",
      text_color: "#ffffff",
      border_radius: 8,
      font_size: 16,
      font_weight: "medium",
    },
  }
}

function generateForm() {
  return {
    type: "Group",
    data: {
      name: "FormularioContato",
      bubble_id: `form_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      layout_mode: "column",
      gap: 15,
      padding: 20,
      elements: [
        {
          type: "Text",
          data: {
            name: "TituloForm",
            bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            text: "Formulário de Contato",
            font_size: 24,
            font_weight: "bold",
          },
        },
        {
          type: "Input",
          data: {
            name: "InputNome",
            bubble_id: `input_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            placeholder: "Seu nome",
            width: 300,
            height: 40,
          },
        },
        {
          type: "Input",
          data: {
            name: "InputEmail",
            bubble_id: `input_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            placeholder: "Seu email",
            input_type: "email",
            width: 300,
            height: 40,
          },
        },
        {
          type: "Button",
          data: {
            name: "BotaoEnviar",
            bubble_id: `btn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            text: "Enviar",
            background_color: "#10b981",
            text_color: "#ffffff",
          },
        },
      ],
    },
  }
}

function generateList() {
  return {
    type: "RepeatingGroup",
    data: {
      name: "ListaItens",
      bubble_id: `rg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      layout_mode: "column",
      gap: 10,
      cell_template: {
        type: "Group",
        data: {
          name: "ItemLista",
          bubble_id: `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          layout_mode: "row",
          gap: 10,
          padding: 15,
          background_color: "#f9fafb",
          border_radius: 8,
          elements: [
            {
              type: "Text",
              data: {
                name: "TituloItem",
                bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                text: "Título do Item",
                font_weight: "bold",
              },
            },
            {
              type: "Text",
              data: {
                name: "DescricaoItem",
                bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                text: "Descrição do item",
                color: "#666666",
              },
            },
          ],
        },
      },
    },
  }
}

function generateGenericGroup(description: string) {
  return {
    type: "Group",
    data: {
      name: "GrupoCustom",
      bubble_id: `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      layout_mode: "column",
      gap: 10,
      padding: 15,
      elements: [
        {
          type: "Text",
          data: {
            name: "TextoDescricao",
            bubble_id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            text: `Elemento baseado em: ${description}`,
            font_size: 16,
          },
        },
      ],
    },
  }
}

// Simulação da chamada para LLM externo
async function callExternalLLM(description: string) {
  // PLACEHOLDER: Aqui você faria a chamada real para o LLM
  // Exemplo de como seria a implementação:
  /*
  const response = await fetch('YOUR_LLM_API_ENDPOINT', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.LLM_API_KEY}`
    },
    body: JSON.stringify({
      prompt: `Generate Bubble.io JSON for: ${description}`,
      max_tokens: 1000
    })
  })
  
  const data = await response.json()
  return JSON.parse(data.choices[0].text)
  */

  // Por enquanto, retorna uma simulação baseada na descrição
  return generateBubbleJson(description)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { description } = body

    if (!description || typeof description !== "string") {
      return NextResponse.json({ error: "Descrição é obrigatória e deve ser uma string" }, { status: 400 })
    }

    if (description.length > 1000) {
      return NextResponse.json({ error: "Descrição muito longa. Máximo 1000 caracteres." }, { status: 400 })
    }

    // Simula delay de processamento do LLM
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Chama o LLM (simulado)
    const bubbleJson = await callExternalLLM(description)

    return NextResponse.json({
      success: true,
      bubbleJson,
      metadata: {
        description,
        generated_at: new Date().toISOString(),
        version: "1.0",
      },
    })
  } catch (error) {
    console.error("Erro ao processar requisição:", error)

    return NextResponse.json(
      {
        error: "Erro interno do servidor ao gerar JSON",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}

// Configuração de CORS para desenvolvimento
export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  })
}
