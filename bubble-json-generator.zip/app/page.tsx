"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  Copy,
  Loader2,
  CheckCircle,
  Eye,
  Code,
  Settings,
  Download,
  History,
  Sparkles,
  Layers,
  Zap,
  Database,
  Smartphone,
  Monitor,
  ImageIcon,
} from "lucide-react"
import { JsonEditor } from "@/components/json-editor"
import { BubblePreview } from "@/components/bubble-preview"
import { TemplateSelector } from "@/components/template-selector"
import { GenerationHistory } from "@/components/generation-history"
import { BubbleVisualization } from "@/components/bubble-visualization"

interface GenerationConfig {
  complexity: "simple" | "intermediate" | "advanced" | "enterprise"
  includeLogic: boolean
  includeWorkflows: boolean
  includeResponsive: boolean
  includeAnimations: boolean
  includeDataBinding: boolean
  targetDevice: "desktop" | "mobile" | "both"
  framework: "bubble" | "bubble-native" | "bubble-api"
}

interface GenerationResult {
  id: string
  description: string
  bubbleJson: any
  config: GenerationConfig
  timestamp: string
  complexity_score: number
  elements_count: number
}

export default function AdvancedBubbleGenerator() {
  const [description, setDescription] = useState("")
  const [generatedJson, setGeneratedJson] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState("input")
  const [generationHistory, setGenerationHistory] = useState<GenerationResult[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [config, setConfig] = useState<GenerationConfig>({
    complexity: "intermediate",
    includeLogic: true,
    includeWorkflows: false,
    includeResponsive: true,
    includeAnimations: false,
    includeDataBinding: true,
    targetDevice: "both",
    framework: "bubble",
  })

  // Carregar histórico do localStorage
  useEffect(() => {
    const saved = localStorage.getItem("bubble-generation-history")
    if (saved) {
      setGenerationHistory(JSON.parse(saved))
    }
  }, [])

  const generateAdvancedJson = async () => {
    if (!description.trim()) {
      setError("Por favor, digite uma descrição do elemento Bubble que deseja criar.")
      return
    }

    setIsLoading(true)
    setError("")
    setGeneratedJson("")

    try {
      const response = await fetch("/api/generate-advanced-bubble-json", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          description: description.trim(),
          config,
          template: selectedTemplate,
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na requisição: ${response.status}`)
      }

      const data = await response.json()
      const formattedJson = JSON.stringify(data.bubbleJson, null, 2)
      setGeneratedJson(formattedJson)

      // Adicionar ao histórico
      const newResult: GenerationResult = {
        id: Date.now().toString(),
        description: description.trim(),
        bubbleJson: data.bubbleJson,
        config,
        timestamp: new Date().toISOString(),
        complexity_score: data.metadata.complexity_score,
        elements_count: data.metadata.elements_count,
      }

      const updatedHistory = [newResult, ...generationHistory.slice(0, 9)]
      setGenerationHistory(updatedHistory)
      localStorage.setItem("bubble-generation-history", JSON.stringify(updatedHistory))

      setActiveTab("preview")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro desconhecido ao gerar JSON")
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = async () => {
    if (!generatedJson) return

    try {
      await navigator.clipboard.writeText(generatedJson)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      setError("Erro ao copiar para a área de transferência")
    }
  }

  const downloadJson = () => {
    if (!generatedJson) return

    const blob = new Blob([generatedJson], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `bubble-element-${Date.now()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const loadFromHistory = (result: GenerationResult) => {
    setDescription(result.description)
    setConfig(result.config)
    setGeneratedJson(JSON.stringify(result.bubbleJson, null, 2))
    setActiveTab("preview")
  }

  const applyTemplate = (template: any) => {
    setDescription(template.description)
    setSelectedTemplate(template.id)
    if (template.config) {
      setConfig({ ...config, ...template.config })
    }
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const fileContent = e.target?.result as string
          const parsedJson = JSON.parse(fileContent)
          setGeneratedJson(JSON.stringify(parsedJson, null, 2))
          setActiveTab("editor")
        } catch (error) {
          setError("Erro ao ler ou analisar o arquivo JSON.")
        }
      }
      reader.readAsText(file)
    }
  }

  const handleDownload = () => {
    downloadJson()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="h-8 w-8 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Gerador Avançado de JSON para Bubble
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Sistema profissional para criação de elementos Bubble complexos com IA, workflows, lógica avançada e preview
            visual
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="input" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              Input
            </TabsTrigger>
            <TabsTrigger value="config" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configuração
            </TabsTrigger>
            <TabsTrigger value="visualization" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Visualização
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="editor" className="flex items-center gap-2">
              <Layers className="h-4 w-4" />
              Editor
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              Histórico
            </TabsTrigger>
          </TabsList>

          {/* Input Tab */}
          <TabsContent value="input" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5" />
                      Descrição Avançada do Elemento
                    </CardTitle>
                    <CardDescription>
                      Descreva elementos complexos, workflows, lógica condicional e integrações
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="Exemplo: Um dashboard de vendas com gráficos interativos, filtros por data, tabela de dados com paginação, botões de ação que disparam workflows para atualizar status, e integração com API externa para sincronizar dados em tempo real"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={8}
                      className="resize-none"
                    />

                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">Workflows</Badge>
                      <Badge variant="outline">APIs</Badge>
                      <Badge variant="outline">Condicionais</Badge>
                      <Badge variant="outline">Dados Dinâmicos</Badge>
                      <Badge variant="outline">Responsivo</Badge>
                    </div>

                    <Button
                      onClick={generateAdvancedJson}
                      disabled={isLoading || !description.trim()}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Gerando Sistema Avançado...
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-2 h-5 w-5" />
                          Gerar Sistema Avançado
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div>
                <TemplateSelector onSelectTemplate={applyTemplate} />
              </div>
            </div>
            <div className="flex gap-2">
              <Button asChild variant="outline">
                <Label htmlFor="import" className="cursor-pointer">
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Importar Bubble JSON
                </Label>
              </Button>
              <input
                type="file"
                id="import"
                className="hidden"
                accept=".json"
                onChange={handleFileChange}
                ref={fileInputRef}
              />
              <Button variant="outline" onClick={handleDownload} disabled={!generatedJson}>
                <Download className="mr-2 h-4 w-4" />
                Exportar Bubble JSON
              </Button>
            </div>
          </TabsContent>

          {/* Configuration Tab */}
          <TabsContent value="config" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações de Geração</CardTitle>
                  <CardDescription>Personalize o nível de complexidade e funcionalidades</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Nível de Complexidade</Label>
                    <Select
                      value={config.complexity}
                      onValueChange={(value: any) => setConfig({ ...config, complexity: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="simple">Simples - Elementos básicos</SelectItem>
                        <SelectItem value="intermediate">Intermediário - Com lógica</SelectItem>
                        <SelectItem value="advanced">Avançado - Workflows complexos</SelectItem>
                        <SelectItem value="enterprise">Enterprise - Sistema completo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Dispositivo Alvo</Label>
                    <Select
                      value={config.targetDevice}
                      onValueChange={(value: any) => setConfig({ ...config, targetDevice: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="desktop">
                          <div className="flex items-center gap-2">
                            <Monitor className="h-4 w-4" />
                            Desktop
                          </div>
                        </SelectItem>
                        <SelectItem value="mobile">
                          <div className="flex items-center gap-2">
                            <Smartphone className="h-4 w-4" />
                            Mobile
                          </div>
                        </SelectItem>
                        <SelectItem value="both">Responsivo (Ambos)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Framework Bubble</Label>
                    <Select
                      value={config.framework}
                      onValueChange={(value: any) => setConfig({ ...config, framework: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bubble">Bubble Web</SelectItem>
                        <SelectItem value="bubble-native">Bubble Native</SelectItem>
                        <SelectItem value="bubble-api">Bubble API</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Funcionalidades Avançadas</CardTitle>
                  <CardDescription>Ative recursos específicos para seu projeto</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Incluir Lógica Condicional</Label>
                      <p className="text-sm text-muted-foreground">Condições e estados dinâmicos</p>
                    </div>
                    <Switch
                      checked={config.includeLogic}
                      onCheckedChange={(checked) => setConfig({ ...config, includeLogic: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Workflows Automáticos</Label>
                      <p className="text-sm text-muted-foreground">Ações e triggers</p>
                    </div>
                    <Switch
                      checked={config.includeWorkflows}
                      onCheckedChange={(checked) => setConfig({ ...config, includeWorkflows: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Design Responsivo</Label>
                      <p className="text-sm text-muted-foreground">Adaptação automática</p>
                    </div>
                    <Switch
                      checked={config.includeResponsive}
                      onCheckedChange={(checked) => setConfig({ ...config, includeResponsive: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Animações</Label>
                      <p className="text-sm text-muted-foreground">Transições e efeitos</p>
                    </div>
                    <Switch
                      checked={config.includeAnimations}
                      onCheckedChange={(checked) => setConfig({ ...config, includeAnimations: checked })}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Binding de Dados</Label>
                      <p className="text-sm text-muted-foreground">Conexão com database</p>
                    </div>
                    <Switch
                      checked={config.includeDataBinding}
                      onCheckedChange={(checked) => setConfig({ ...config, includeDataBinding: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Visualization Tab */}
          <TabsContent value="visualization" className="space-y-6">
            <BubbleVisualization json={generatedJson} />
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Preview Visual
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={copyToClipboard}>
                        {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadJson}>
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <BubblePreview json={generatedJson} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>JSON Gerado</CardTitle>
                  <CardDescription>Código pronto para importar no Bubble</CardDescription>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={generatedJson}
                    readOnly
                    rows={20}
                    className="resize-none font-mono text-xs"
                    placeholder="O JSON gerado aparecerá aqui..."
                  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Editor Tab */}
          <TabsContent value="editor" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Editor de JSON Avançado</CardTitle>
                <CardDescription>Edite manualmente o JSON gerado com validação em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <JsonEditor value={generatedJson} onChange={setGeneratedJson} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <GenerationHistory
              history={generationHistory}
              onLoadFromHistory={loadFromHistory}
              onClearHistory={() => {
                setGenerationHistory([])
                localStorage.removeItem("bubble-generation-history")
              }}
            />
          </TabsContent>
        </Tabs>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Advanced Features Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Recursos Avançados Disponíveis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2">
                <h4 className="font-semibold">Elementos Complexos</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Dashboards interativos</li>
                  <li>• Formulários multi-etapa</li>
                  <li>• Tabelas com filtros</li>
                  <li>• Gráficos dinâmicos</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Workflows & Lógica</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Condições automáticas</li>
                  <li>• Triggers de eventos</li>
                  <li>• Estados dinâmicos</li>
                  <li>• Validações complexas</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Integrações</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• APIs externas</li>
                  <li>• Webhooks</li>
                  <li>• Sincronização de dados</li>
                  <li>• Autenticação OAuth</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">UX Avançada</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Animações fluidas</li>
                  <li>• Design responsivo</li>
                  <li>• Temas dinâmicos</li>
                  <li>• Acessibilidade</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
